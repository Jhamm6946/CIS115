using System.Numerics;

namespace Daily_Temps
{
    public partial class Form1 : Form
    {
        List<int> daily = new List<int>();
        int totaltemp = 0;
        int enteredtemp = 0;

        

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int temp))
            {
                if (temp >= -20 && temp <= 130)
                {
                    daily.Add(temp);
                    totaltemp += temp;
                    enteredtemp++;
                    textBox1.Clear();

                    if (enteredtemp == 7)
                    {
                        button1.Enabled = false;
                        int average = totaltemp / 7;
                        string list = string.Join(", ", daily);
                        label2.Text = "The Temperatures you entered were: " + list ;
                        label3.Text = "The average Temperature for the week was: " + average + " degrees Farenheit";
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter a Number Between -20 and 130");
                }
            }
            else
            {
                MessageBox.Show("Please Enter a Whole Number");
            }
        }
    }
}
