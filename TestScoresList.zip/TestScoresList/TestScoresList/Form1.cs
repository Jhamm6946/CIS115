namespace TestScoresList
{
    public partial class Form1 : Form
    {
        int y = -1;
        public Form1()


        {
            InitializeComponent();
        }

        double[] grades = new double[] { 0, 0, 0, 0, 0, 0, 0, 0 };
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double g1))
            {
                y++;
                grades[y] += g1;
                textBox1.Clear();

                if (y == 7)
                {
                    double average = grades.Average();


                    for (int x = 0; x < 8; x++)
                    {
                        double difference = grades[x] - average;
                        listBox1.Items.Add(x + 1 + ". grade was: " + grades[x] + " and the difference from the average was: " + difference);
                    }

                    label2.Text = "Average: " + average;
                }

            }
            else
            {
                MessageBox.Show("Please enter valid integer values for all test scores.");
            }
        }
    }
}
