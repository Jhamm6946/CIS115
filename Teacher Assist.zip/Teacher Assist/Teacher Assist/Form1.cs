namespace Teacher_Assist
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Variables that determines the index of the arrays
        int A1 = -1;
        int A2 = -1;
        int A3 = -1;

        // Array to hold both student names 
        string[] Names = new string[20];

        // 20 seperate arrays to hold the score data for each student
        int[] student1 = new int[5];
        int[] student2 = new int[5];
        int[] student3 = new int[5];
        int[] student4 = new int[5];
        int[] student5 = new int[5];
        int[] student6 = new int[5];
        int[] student7 = new int[5];
        int[] student8 = new int[5];
        int[] student9 = new int[5];
        int[] student10 = new int[5];
        int[] student11 = new int[5];
        int[] student12 = new int[5];
        int[] student13 = new int[5];
        int[] student14 = new int[5];
        int[] student15 = new int[5];
        int[] student16 = new int[5];
        int[] student17 = new int[5];
        int[] student18 = new int[5];
        int[] student19 = new int[5];
        int[] student20 = new int[5];

        // Array to hold the chores that the student is assigned
        string[] Chores = new string[20];

        // Array to hold all the averages for class average calculation
        double[] Averages = new double[20];
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt1.Text) || string.IsNullOrEmpty(txt2.Text))//prevents anything from happening if text boxes are empty
            {
                MessageBox.Show("Please enter a valid Name or Chore");//displays this message if text boxes are empty
            }
            // if text boxes are not empty, the code will run
            else
            {
                A1++;// adds 1 to A1 every time the button is clicked 
                string name = txt1.Text; // sets the variable "name" to the textbox 1 input
                Names[A1] += name;// adds the input from the textbox 1 to the index of A1
                txt1.Clear();// clears the textbox when the button is clicked
                string chore = txt2.Text;// sets the variable "chore" to the textbox 2 input
                Chores[A1] += chore;// adds the input from textbox 2 to the index of A1 
                txt2.Clear();// clears the textbox when the button is clicked
                lb1.Items.Add(Names[A1] + ", " + Chores[A1]);// adds name and chore to listbox 1

                if (A1 == 19)
                {
                    btnEnter1.Enabled = false;// if A1 is equal to 19, the enter button is disabled
                }
            }
            }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = txt1.Text; // sets the variable "name" to the textbox 1 input
            int I = Array.IndexOf(Names, name);// figures out which index in the array, the name is set to and sets I to it
            Names.Where((value, index) => index != I).ToArray();// removes the value at index I in the array
            Chores.Where((value, index) => index != I).ToArray();// removes the value at index I in the array
            lb1.Items.RemoveAt(I);// removes the value in the listbox at index of I
            txt1.Clear();// clears textbox 1
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Array.Clear(Names, 0, Names.Length);// clears the names array
            Array.Clear(Chores, 0, Chores.Length);// clears the chores array
            lb1.Items.Clear();// clears listbox 1
            A1 = -1;// sets A1 back to -1
        }

        private void btnEnter2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt3.Text) || string.IsNullOrEmpty(txt4.Text))//prevents anything from happening if text boxes are empty or have an invalid character
            {
                MessageBox.Show("Please enter a valid Name or Grade");// displays if textbox is empty
            }
            //if the textboxes are not empty then the code runs
            else
            {
                A2++;// adds 1 to A2
                string name = txt3.Text; // sets the variable "name" to the textbox 3 input
                if (int.TryParse(txt4.Text, out int score)) ;  // sets the variable "score" to the textbox 4 input and prevents program from crashing if input is invalid
                else
                {
                    MessageBox.Show("Please enter valid integer for the grade ");
                }
                int I = Array.IndexOf(Names, name);// figures out which index in the array, the name is set to and sets I to it
                string chore = Chores[I];//sets the I index of Chores to chore
                label1.Text = ("Chore: " + chore);// sets the text of label 1 to the value of chore
                txt4.Clear();//clears textbox 4

                if (A2 == 4)
                {
                    btnEnter2.Enabled = false;// if te variable A2 is equal to a, enter button 2 is disabled
                }
                List<int[]> students = new List<int[]>// makes a list with all the score arrays to prevent a bucnch of if statements
            {
            student1, student2, student3, student4, student5,
            student6, student7, student8, student9, student10,
            student11, student12, student13, student14, student15,
            student16, student17, student18, student19, student20
            };

                if (I >= 0 && I < 20)
                {
                    students[I][A2] += score;// if I is less than 20, the specified array is set to the value of score
                    lb2.Items.Add(score);// adds the value of score to list box 2
                }
            }
        }

        private void btnEnter3_Click(object sender, EventArgs e)
        {
                if (A2 < 4)
                {
                    MessageBox.Show("Please Enter 5 Grades");// if the variable A2 is less than 4, No other code can run
                }
                else
                {
                A3++;// adds 1 to m
                string name = txt3.Text;//sets the variable "name" to the value of textbox 3
                int I = Array.IndexOf(Names, name);// figures out which index in the array, the name is set to and sets I to it
                label1.Text = ("Chore:");// Resets label1
                List<int[]> students = new List<int[]>// makes a list with all the score arrays to prevent a bucnch of if statements
            {
            student1, student2, student3, student4, student5,
            student6, student7, student8, student9, student10,
            student11, student12, student13, student14, student15,
            student16, student17, student18, student19, student20
            };

                if (I >= 0 && I < 20)
                {


                    double Average = students[I].Average();// takes the average of the specified array and sets the variable z to it 
                    Averages[A3] += Average;// adds the value of z to the Averages array at the index specified by m
                    lb3.Items.Add(Average);// adds the value of z to listbox 3
                    btnEnter2.Enabled = true;// Enables enter button 2
                    A2 = -1;// resets A2 back to -1
                    txt3.Clear();// clears text box 3
                    txt4.Clear();// clearss text box 4
                    lb2.Items.Clear();// clears items in List box 2

                }
            }
               
            
        }

        private void btnReset2_Click(object sender, EventArgs e)
        {

            lb3.Items.Clear();// clears list box 3
        }

        private void btnAverages_Click(object sender, EventArgs e)
        {
            for (int n = 0; n <= 19; n++)// when the button is clicked, 1 gets added to n until it reaches 19
            {
                lb4.Items.Add(Averages[n]);//the index specified by n is displayed in text box 4
            }
        }
    }
}
