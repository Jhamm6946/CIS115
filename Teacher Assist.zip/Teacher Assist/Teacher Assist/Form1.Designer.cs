﻿namespace Teacher_Assist
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEnter1 = new Button();
            btnRemove = new Button();
            btnClear = new Button();
            btnEnter2 = new Button();
            btnEnter3 = new Button();
            btnReset2 = new Button();
            btnAverages = new Button();
            txt1 = new TextBox();
            txt2 = new TextBox();
            txt3 = new TextBox();
            txt4 = new TextBox();
            lb1 = new ListBox();
            lb2 = new ListBox();
            lb4 = new ListBox();
            lb3 = new ListBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            SuspendLayout();
            // 
            // btnEnter1
            // 
            btnEnter1.Location = new Point(79, 224);
            btnEnter1.Name = "btnEnter1";
            btnEnter1.Size = new Size(75, 23);
            btnEnter1.TabIndex = 0;
            btnEnter1.Text = "Add";
            btnEnter1.UseVisualStyleBackColor = true;
            btnEnter1.Click += button1_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(79, 253);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(75, 23);
            btnRemove.TabIndex = 1;
            btnRemove.Text = "Remove";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += button2_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(79, 282);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(75, 23);
            btnClear.TabIndex = 2;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += button3_Click;
            // 
            // btnEnter2
            // 
            btnEnter2.Location = new Point(330, 193);
            btnEnter2.Name = "btnEnter2";
            btnEnter2.Size = new Size(75, 23);
            btnEnter2.TabIndex = 3;
            btnEnter2.Text = "Add";
            btnEnter2.UseVisualStyleBackColor = true;
            btnEnter2.Click += btnEnter2_Click;
            // 
            // btnEnter3
            // 
            btnEnter3.Location = new Point(330, 344);
            btnEnter3.Name = "btnEnter3";
            btnEnter3.Size = new Size(75, 23);
            btnEnter3.TabIndex = 4;
            btnEnter3.Text = "Enter";
            btnEnter3.UseVisualStyleBackColor = true;
            btnEnter3.Click += btnEnter3_Click;
            // 
            // btnReset2
            // 
            btnReset2.Location = new Point(330, 373);
            btnReset2.Name = "btnReset2";
            btnReset2.Size = new Size(75, 23);
            btnReset2.TabIndex = 5;
            btnReset2.Text = "Reset";
            btnReset2.UseVisualStyleBackColor = true;
            btnReset2.Click += btnReset2_Click;
            // 
            // btnAverages
            // 
            btnAverages.Location = new Point(565, 332);
            btnAverages.Name = "btnAverages";
            btnAverages.Size = new Size(75, 23);
            btnAverages.TabIndex = 6;
            btnAverages.Text = "Averages";
            btnAverages.UseVisualStyleBackColor = true;
            btnAverages.Click += btnAverages_Click;
            // 
            // txt1
            // 
            txt1.Location = new Point(67, 113);
            txt1.Name = "txt1";
            txt1.Size = new Size(100, 23);
            txt1.TabIndex = 7;
            // 
            // txt2
            // 
            txt2.Location = new Point(67, 164);
            txt2.Name = "txt2";
            txt2.Size = new Size(100, 23);
            txt2.TabIndex = 8;
            // 
            // txt3
            // 
            txt3.Location = new Point(307, 110);
            txt3.Name = "txt3";
            txt3.Size = new Size(120, 23);
            txt3.TabIndex = 9;
            // 
            // txt4
            // 
            txt4.Location = new Point(307, 155);
            txt4.Name = "txt4";
            txt4.Size = new Size(120, 23);
            txt4.TabIndex = 10;
            // 
            // lb1
            // 
            lb1.FormattingEnabled = true;
            lb1.ItemHeight = 15;
            lb1.Location = new Point(57, 358);
            lb1.Name = "lb1";
            lb1.Size = new Size(120, 94);
            lb1.TabIndex = 12;
            // 
            // lb2
            // 
            lb2.FormattingEnabled = true;
            lb2.ItemHeight = 15;
            lb2.Location = new Point(307, 244);
            lb2.Name = "lb2";
            lb2.Size = new Size(120, 94);
            lb2.TabIndex = 13;
            // 
            // lb4
            // 
            lb4.FormattingEnabled = true;
            lb4.ItemHeight = 15;
            lb4.Location = new Point(539, 164);
            lb4.Name = "lb4";
            lb4.Size = new Size(120, 94);
            lb4.TabIndex = 14;
            // 
            // lb3
            // 
            lb3.FormattingEnabled = true;
            lb3.ItemHeight = 15;
            lb3.Location = new Point(307, 431);
            lb3.Name = "lb3";
            lb3.Size = new Size(120, 19);
            lb3.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(307, 226);
            label1.Name = "label1";
            label1.Size = new Size(42, 15);
            label1.TabIndex = 16;
            label1.Text = "Chore:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(236, 62);
            label2.Name = "label2";
            label2.Size = new Size(10, 390);
            label2.TabIndex = 17;
            label2.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(-1, 62);
            label3.Name = "label3";
            label3.Size = new Size(802, 15);
            label3.TabIndex = 18;
            label3.Text = "---------------------------------------------------------------------------------------------------------------------------------------------------------------\r\n";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(478, 77);
            label5.Name = "label5";
            label5.Size = new Size(10, 375);
            label5.TabIndex = 20;
            label5.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Impact", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(230, 9);
            label4.Name = "label4";
            label4.Size = new Size(258, 45);
            label4.TabIndex = 21;
            label4.Text = "TEACHER ASSIST";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(340, 413);
            label6.Name = "label6";
            label6.Size = new Size(53, 15);
            label6.TabIndex = 22;
            label6.Text = "Average:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(19, 116);
            label7.Name = "label7";
            label7.Size = new Size(42, 15);
            label7.TabIndex = 23;
            label7.Text = "Name:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(19, 167);
            label8.Name = "label8";
            label8.Size = new Size(42, 15);
            label8.TabIndex = 24;
            label8.Text = "Chore:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(60, 340);
            label9.Name = "label9";
            label9.Size = new Size(107, 15);
            label9.TabIndex = 25;
            label9.Text = "Names and Chores";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(259, 113);
            label10.Name = "label10";
            label10.Size = new Size(42, 15);
            label10.TabIndex = 26;
            label10.Text = "Name:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(260, 158);
            label11.Name = "label11";
            label11.Size = new Size(41, 15);
            label11.TabIndex = 27;
            label11.Text = "Grade:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(552, 146);
            label12.Name = "label12";
            label12.Size = new Size(88, 15);
            label12.TabIndex = 28;
            label12.Text = "Class Averages:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(714, 473);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lb3);
            Controls.Add(lb4);
            Controls.Add(lb2);
            Controls.Add(lb1);
            Controls.Add(txt4);
            Controls.Add(txt3);
            Controls.Add(txt2);
            Controls.Add(txt1);
            Controls.Add(btnAverages);
            Controls.Add(btnReset2);
            Controls.Add(btnEnter3);
            Controls.Add(btnEnter2);
            Controls.Add(btnClear);
            Controls.Add(btnRemove);
            Controls.Add(btnEnter1);
            Name = "Form1";
            Text = "Teacher Assist";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEnter1;
        private Button btnRemove;
        private Button btnClear;
        private Button btnEnter2;
        private Button btnEnter3;
        private Button btnReset2;
        private Button btnAverages;
        private TextBox txt1;
        private TextBox txt2;
        private TextBox txt3;
        private TextBox txt4;
        private ListBox lb1;
        private ListBox lb2;
        private ListBox lb4;
        private ListBox lb3;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label5;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
    }
}
