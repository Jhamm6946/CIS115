namespace DeliveryCharges
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double[] zipCodes = { 28734, 28748, 28763, 28781, 28775, 28744, 28786, 28779, 28723, 28789 };
        double[] Charges = { 5.50, 5.30, 3.99, 4.50, 2.00, 5.65, 4.45, 4.99, 5.30, 6.55 };

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double ZipCodeIn))
            {

                int x = Array.IndexOf(zipCodes, ZipCodeIn);

                if (x != -1)
                {
                    label1.Text = ("Delivery charge to " +ZipCodeIn + ": $" + Charges[x]);
                }
                else
                {
                    MessageBox.Show("We do not deliver to this zip code");
                }
            }
            else
            {
                MessageBox.Show("Please enter a Zip Code");
            }
        }
    }
}
