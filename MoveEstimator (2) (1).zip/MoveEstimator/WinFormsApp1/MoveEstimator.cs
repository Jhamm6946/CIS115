using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class MoveEstimator : Form
    {
        public MoveEstimator()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            int IHours, IMiles;
            IHours = Convert.ToInt32(textBox1.Text);
            IMiles = Convert.ToInt32(textBox2.Text);
            int OHours = 150 * IHours;
            int Omiles = 2 * IMiles;
            int Total = 200 + OHours + Omiles;
            MessageBox.Show("For a move taking " + IHours + " hours and going " + IMiles + " miles the estimate is $" + Total + ".00");

        }
    } 
}
