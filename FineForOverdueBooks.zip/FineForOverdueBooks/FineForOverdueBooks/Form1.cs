namespace FineForOverdueBooks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int Books)) ;
            else
            {
                MessageBox.Show("Please enter a valid integer for amount of books");
            }
            if (int.TryParse(textBox2.Text, out int Days)) ;
            else
            {
                MessageBox.Show("please enter a valid integer for amount of days overdue");
            }
            
            decimal fine = Calculate(Books, Days);

            label1.Text = ("Library Overdue fine: $" + fine);


        }
        private decimal Calculate(int Books, int Days)
        {
            decimal fineRate = 0.10m;  
            decimal fine = 0;
            int DaysAfterSeven = Days - 7;

            fine += Books * Days * fineRate;

            if (Days > 7)
            {
                fine += Books * DaysAfterSeven * fineRate;
            }

            return fine;
        }
    }
}
