namespace Multiplication_Table
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int inputNumber))
            {
                listBox1.Items.Clear();
                for (int i = 1; i <= 10; i++)
                {
                    int OutputValues = inputNumber * i;
                    listBox1.Items.Add($"{i} * {inputNumber} = {OutputValues}");
                }
            }
            else
            {
                MessageBox.Show("Please Enter A Valid Integer");
            }

        }
    }
}
