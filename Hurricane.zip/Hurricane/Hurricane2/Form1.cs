namespace Hurricane2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Windspeed;
            Windspeed = Convert.ToInt32(textBox1.Text);

            if (Windspeed >= 157)
            {
                MessageBox.Show("A Windspeed of " + Windspeed + " MPH Is A Category 5 Hurricane");
            }
            else if (Windspeed >= 130)
            {
                MessageBox.Show("A Windspeed of " + Windspeed + " MPH Is A Category 4 Hurricane");
            }
            else if (Windspeed >= 111)
            {
                MessageBox.Show("A Windspeed of " + Windspeed + " MPH Is A Category 3 Hurricane");
            }
            else if (Windspeed >= 96)
            {
                MessageBox.Show("A Windspeed of " + Windspeed + " MPH Is A Category 2 Hurricane");
            }
            else if (Windspeed >= 74)
            {
                MessageBox.Show("A Windspeed of " + Windspeed + " MPH Is A Category 1 Hurricane");
            }
            else
            {
                MessageBox.Show("A Windspeed of " + Windspeed + " MPH Is Not A Hurricane");
            }
        }
    }
}
